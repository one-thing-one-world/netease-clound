export declare const transition: (showDefaultValue: boolean) => string;
